from __future__ import annotations
import json
from pathlib import Path
from typing import Any

DATA = Path(__file__).parent / "data" / "hotels.json"

def load_hotels() -> list[dict[str, Any]]:
    return json.loads(DATA.read_text(encoding="utf-8"))

def search_hotels(area: str = "", max_nightly_eur: float | None = None,
                  min_stars: int | None = None, amenities: list[str] | None = None) -> list[dict[str, Any]]:
    """Return hotel records matching explicit traveler constraints."""
    amenities = [a.lower() for a in (amenities or [])]
    out = []
    for h in load_hotels():
        if area and area.lower() not in h["area"].lower():
            continue
        if max_nightly_eur is not None and h["nightly_eur"] > max_nightly_eur:
            continue
        if min_stars is not None and h["stars"] < min_stars:
            continue
        have = {a.lower() for a in h["amenities"]}
        if any(a not in have for a in amenities):
            continue
        out.append(h)
    return out

def calculate_stay_total(nightly_eur: float, nights: int) -> float:
    """Calculate room subtotal before taxes/fees."""
    if nightly_eur < 0 or nights < 1:
        raise ValueError("nightly_eur must be non-negative and nights must be at least 1")
    return round(nightly_eur * nights, 2)

def get_hotel(hotel_id: str) -> dict[str, Any] | None:
    """Look up one hotel by its internal ID."""
    return next((h for h in load_hotels() if h["id"] == hotel_id), None)
