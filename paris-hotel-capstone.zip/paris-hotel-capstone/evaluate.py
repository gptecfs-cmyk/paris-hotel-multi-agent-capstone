"""Small evaluation harness: constraint tests plus optional LLM-as-a-Judge."""
from app import run

TESTS = [
    ("Find a hotel under €150 per night with wifi for 2 nights.", True),
    ("Find a 4-star hotel under €200 with breakfast for 2 nights.", True),
    ("Find a 5-star hotel under €80 with a gym.", False),
]

def deterministic_eval():
    passed = 0
    for prompt, expect_match in TESTS:
        result = run(prompt, use_ollama=False)
        got_match = "could not find" not in result["final"].lower()
        ok = result["verified"] and got_match == expect_match
        passed += int(ok)
        print(f"{'PASS' if ok else 'FAIL'} | {prompt}\n  {result['final']}\n")
    print(f"Deterministic checks: {passed}/{len(TESTS)} passed")

if __name__ == "__main__":
    deterministic_eval()
