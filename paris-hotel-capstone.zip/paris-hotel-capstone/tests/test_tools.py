import unittest
from hotel_tools import search_hotels, calculate_stay_total

class ToolTests(unittest.TestCase):
    def test_budget_filter(self):
        rows = search_hotels(max_nightly_eur=150)
        self.assertTrue(rows)
        self.assertTrue(all(x["nightly_eur"] <= 150 for x in rows))
    def test_total(self):
        self.assertEqual(calculate_stay_total(145, 3), 435)
    def test_amenity(self):
        rows = search_hotels(amenities=["gym"])
        self.assertTrue(all("gym" in x["amenities"] for x in rows))

if __name__ == "__main__": unittest.main()
