# Paris Hotel Multi-Agent Recommendation Assistant

A local, reproducible capstone project using **LangGraph + LangChain + Ollama**. The workflow uses four specialist stages coordinated as a supervisor-style graph: Preference → Retrieval → Comparison → Verification.

## What it demonstrates
- Multi-agent coordination with LangGraph
- Local LLM reasoning through `ChatOllama`
- Deterministic hotel lookup and price-calculation tools
- The same tools exposed through an MCP server
- Short-term graph state for the current trip
- Retrieval from a local hotel knowledge base
- A verification/safety gate that blocks unsupported, over-budget, live-availability, booking, and payment claims
- Evaluation tests, including planted weak/no-match cases

## Requirements
- Python 3.10+
- Ollama installed and running

## Install
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
ollama pull llama3.2
```

## Run the full Ollama system
```bash
python app.py "Find me a 3-star Paris hotel under €160 per night with wifi for 3 nights."
```

## Run deterministic demo mode
This is useful for checking the workflow without an Ollama call:
```bash
python app.py --demo
```

## Run evaluation and tests
```bash
python evaluate.py
python -m unittest discover -s tests -v
```

## Run the MCP tool server
```bash
python mcp_server.py
```
The MCP server exposes `search_hotels`, `calculate_stay_total`, and `get_hotel`. The application uses the same underlying functions locally, so tool behavior stays consistent.

## Architecture
```text
User
  ↓
Supervisor-style LangGraph
  ↓
Preference Agent
  ↓
Retrieval Agent → hotel tools / local KB
  ↓
Comparison Agent
  ↓
Verification Agent → safety/grounding check
  ↓
Final response
```

## Safety design
The system does not perform real bookings or payments. The stated budget is treated as a hard constraint unless the traveler explicitly changes it. Hotel facts must come from retrieved records. The verifier blocks unsupported hotel mentions and claims such as “booking confirmed,” “payment confirmed,” or unverified live availability.

## Data note
`data/hotels.json` is a small synthetic/local demonstration knowledge base. Prices are examples for coursework, not live market prices or availability.

## GitHub submission
Create a repository, copy these files into it, commit, and push. Do not add API keys or secrets. Then paste the public/private repository URL into the report where marked.
