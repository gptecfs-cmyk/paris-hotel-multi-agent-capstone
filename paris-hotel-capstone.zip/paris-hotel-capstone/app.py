from __future__ import annotations
import argparse, json, re
from typing import TypedDict, Any
from hotel_tools import search_hotels, calculate_stay_total

SYSTEM_RULES = """You are part of a Paris hotel recommendation system.
Use only supplied hotel records for hotel facts. Never invent live availability, taxes, fees, or booking confirmation.
Treat the user's stated budget as a hard maximum unless the user explicitly changes it.
The system recommends and compares only; any consequential booking/payment action requires separate human confirmation."""

class State(TypedDict, total=False):
    query: str
    preferences: dict[str, Any]
    retrieved: list[dict[str, Any]]
    draft: str
    verified: bool
    final: str
    issues: list[str]


def _json_from_text(text: str) -> dict[str, Any]:
    m = re.search(r"\{.*\}", text, re.S)
    if not m: raise ValueError("No JSON object returned")
    return json.loads(m.group(0))


def preference_agent(state: State, llm=None) -> State:
    q = state["query"]
    if llm:
        prompt = SYSTEM_RULES + """\nExtract preferences as JSON only with keys:
max_nightly_eur (number or null), area (string), min_stars (integer or null), nights (integer), amenities (array of strings).
Do not infer a budget that was not stated.\nUSER: """ + q
        prefs = _json_from_text(llm.invoke(prompt).content)
    else:
        money = re.search(r"(?:€|EUR\s*)(\d+(?:\.\d+)?)", q, re.I)
        nights = re.search(r"(\d+)\s*nights?", q, re.I)
        stars = re.search(r"(\d)\s*[- ]?star", q, re.I)
        known_areas = ["2nd arrondissement","5th arrondissement","9th arrondissement","11th arrondissement","15th arrondissement","18th arrondissement"]
        area = next((a for a in known_areas if a.lower() in q.lower()), "")
        amenities = [a for a in ["wifi","breakfast","gym","air conditioning","workspace"] if a in q.lower()]
        prefs = {"max_nightly_eur": float(money.group(1)) if money else None, "area": area,
                 "min_stars": int(stars.group(1)) if stars else None,
                 "nights": int(nights.group(1)) if nights else 1, "amenities": amenities}
    return {**state, "preferences": prefs}


def retrieval_agent(state: State) -> State:
    p = state["preferences"]
    rows = search_hotels(p.get("area", ""), p.get("max_nightly_eur"), p.get("min_stars"), p.get("amenities", []))
    for h in rows:
        h["stay_total_eur"] = calculate_stay_total(h["nightly_eur"], int(p.get("nights", 1)))
    return {**state, "retrieved": rows}


def comparison_agent(state: State, llm=None) -> State:
    rows, p = state["retrieved"], state["preferences"]
    if not rows:
        return {**state, "draft": "I could not find a hotel in the local knowledge base that matches all of those constraints."}
    if llm:
        prompt = SYSTEM_RULES + f"""\nTraveler preferences: {json.dumps(p)}
Retrieved records: {json.dumps(rows)}
Write a short comparison and recommendation. Cite hotel IDs in square brackets after factual claims, for example [H01].
Do not claim live availability or that a booking was made."""
        draft = llm.invoke(prompt).content
    else:
        ranked = sorted(rows, key=lambda h: (h["nightly_eur"], -h["stars"]))
        h = ranked[0]
        draft = (f"A strong match is {h['name']} [${h['id']}$], a {h['stars']}-star hotel in {h['area']} "
                 f"at €{h['nightly_eur']:.0f} per night. For {p.get('nights',1)} night(s), the room subtotal is "
                 f"€{h['stay_total_eur']:.2f}. Amenities in the local record: {', '.join(h['amenities'])}. ")
        draft = draft.replace("[$", "[").replace("$]", "]")
    return {**state, "draft": draft}


def verification_agent(state: State) -> State:
    draft, rows, p = state["draft"], state["retrieved"], state["preferences"]
    issues = []
    lower = draft.lower()
    if any(x in lower for x in ["booked", "payment confirmed", "reservation confirmed", "live availability"]):
        issues.append("Draft makes a consequential or live-status claim that the system cannot verify.")
    budget = p.get("max_nightly_eur")
    if budget is not None:
        for h in rows:
            if h["nightly_eur"] > budget and h["name"].lower() in lower:
                issues.append(f"{h['name']} exceeds the stated nightly budget.")
    known_names = {h["name"] for h in rows}
    all_names = {h["name"] for h in __import__('hotel_tools').load_hotels()}
    for name in all_names - known_names:
        if name.lower() in lower:
            issues.append(f"Draft mentions {name}, which was not in retrieved evidence.")
    ok = not issues
    final = draft if ok else "I could not verify the draft safely. " + " ".join(issues)
    return {**state, "verified": ok, "issues": issues, "final": final}


def build_graph(llm=None):
    try:
        from langgraph.graph import StateGraph, START, END
        graph = StateGraph(State)
        graph.add_node("preference_agent", lambda s: preference_agent(s, llm))
        graph.add_node("retrieval_agent", retrieval_agent)
        graph.add_node("comparison_agent", lambda s: comparison_agent(s, llm))
        graph.add_node("verification_agent", verification_agent)
        graph.add_edge(START, "preference_agent")
        graph.add_edge("preference_agent", "retrieval_agent")
        graph.add_edge("retrieval_agent", "comparison_agent")
        graph.add_edge("comparison_agent", "verification_agent")
        graph.add_edge("verification_agent", END)
        return graph.compile()
    except ImportError:
        # Lightweight fallback keeps --demo runnable before dependencies are installed.
        class SequentialDemoGraph:
            def invoke(self, state):
                state = preference_agent(state, llm)
                state = retrieval_agent(state)
                state = comparison_agent(state, llm)
                return verification_agent(state)
        return SequentialDemoGraph()


def run(query: str, use_ollama: bool = True) -> State:
    llm = None
    if use_ollama:
        from langchain_ollama import ChatOllama
        llm = ChatOllama(model="llama3.2", temperature=0)
    return build_graph(llm).invoke({"query": query})

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("query", nargs="?", default="Find me a 3-star Paris hotel under €160 per night with wifi for 3 nights.")
    ap.add_argument("--demo", action="store_true", help="Use deterministic parsing/generation; still runs the LangGraph workflow.")
    args = ap.parse_args()
    result = run(args.query, use_ollama=not args.demo)
    print("\nFINAL RESPONSE\n" + result["final"])
    print("\nVERIFIED:", result["verified"])
    if result.get("issues"): print("ISSUES:", result["issues"])
