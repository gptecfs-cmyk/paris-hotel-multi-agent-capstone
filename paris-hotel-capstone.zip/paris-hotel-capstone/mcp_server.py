"""MCP exposure of the same deterministic hotel tools used by the agents."""
from fastmcp import FastMCP
from hotel_tools import search_hotels, calculate_stay_total, get_hotel

mcp = FastMCP("paris-hotel-tools")
mcp.tool(search_hotels)
mcp.tool(calculate_stay_total)
mcp.tool(get_hotel)

if __name__ == "__main__":
    mcp.run()
